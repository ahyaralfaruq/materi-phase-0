// 1. Menyusun Barisan Bintang

// Problem:
// Pada tugas ini kamu diminta untuk melakukan looping dalam JavaScript untuk menampilkan di console barisan asterisks (bintang). Setiap baris memiliki 1 simbol '*'.

// Skeleton Code:
// var rows1; // input the number of rows

// // do loops to display asterisks in the console.

// Output:
// jika rows1 = 5

// *
// *
// *
// *
// *


// my code :

var rows1 = 5
var star = "*"

for(var i = 0; i < rows1; i++){

    console.log(star)
}