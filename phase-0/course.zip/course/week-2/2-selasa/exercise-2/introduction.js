// source by ===> https://www.codecademy.com/courses/introduction-to-javascript/lessons/introduction-to-javascript/exercises/review

console.log(1999)

console.log("===============================")

// Nama Saya Muhammad Ahyar

/*
Muhammad
Akhyar
Alfaruq
*/

console.log("===============================")
// data type

console.log("Maret") // string
console.log(29); // number
console.log(true) // boolean
console.log(null) // null
var test
console.log(test) // undifined
console.log('Woohoo! I love to code! #codecademy') // symbol
console.log(Math.random() * 100) // object

console.log("===============================")

console.log(23.8879) // number without quotes

console.log("===============================")

console.log("Muhammad") // double quotes
console.log('Ahyar') // single quotes

console.log("===============================")

console.log(8 + 1)
console.log(10 - 7)
console.log(200 * 10)
console.log(1999 / 1)
console.log(50 % 5)

console.log("===============================")

// string property

console.log('Hallo'.length)

console.log("===============================")

// string object

console.log('Hallo'.toUpperCase())

console.log("===============================")

console.log('   what ?!    '.trim())

console.log("===============================")

// object math

console.log(Math.floor(22.8))
console.log(Math.ceil(22.1))
console.log(Math.round(22.5))