// Directions:
// 1. Lanjutkan kode berikut ini hingga dapat menampilkan nilai / output yang diminta!

// Tugas 1 :
// Buatlah sebuah fungsi bernama shoutOut(), yang mengembalikan nilai berupa "Halo Function!", yang kemudian akan ditampilkan di console.

/*
 BUATLAH KODE FUNCTION DISINI
*/

function shoutOut() {
    return "Halo Function!"
}


console.log(shoutOut()) // Menampilkan "Halo Function!" di console