console.log("HUKUM NEWTON II");
// =================================================================== HUKUM NEWTON II

// diketahui massa benda (m) = 600 kg.
const massa = 600;

// diketahui percepatan benda (m/s2)  = 2 m/s2
const percepatanBenda = 2;

// rumus resultan gaya (Newton) ==> Newton = m x a
const resultanGaya = massa * percepatanBenda;

console.log(resultanGaya)